installing

npm install dotenv telegram input fs node-telegram-bot-api


start run

node login.js